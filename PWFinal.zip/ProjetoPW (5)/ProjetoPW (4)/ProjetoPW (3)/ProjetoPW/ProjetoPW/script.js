const modelagemButton = document.getElementById('modelagem');
modelagemButton.addEventListener('click', () => {
    window.location.href = 'nova_tela.html';
});

const simulacaoButton = document.getElementById('simulacao');
simulacaoButton.addEventListener('click', () => {
    window.location.href = 'imulacao.html';
});

const analiseButton = document.getElementById('analise');
analiseButton.addEventListener('click', () => {
    window.location.href = 'analise.html';
});

const colaboracaoButton = document.getElementById('colaboracao');
colaboracaoButton.addEventListener('click', () => {
    window.location.href = 'colaboracao.html';
});

const sobreButton = document.getElementById('sobre');
sobreButton.addEventListener('click', () => {
    window.location.href = 'obre.html';
});

const integracaoButton = document.getElementById('integracao');
integracaoButton.addEventListener('click', () => {
    window.location.href = 'integracao.html';
});

